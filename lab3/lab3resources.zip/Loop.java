public class Loop {
    public static void main(String args[]) {
        System.out.println("Do not leave running, especially on Joshua. We know who you are :)");
        System.out.println("Going into infinite loop...");
        while (true);
    }
}